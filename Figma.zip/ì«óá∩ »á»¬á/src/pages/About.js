import React from 'react'

function About() {
  return (
    <div>
      <h1>About</h1>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam,
        officiis aspernatur minima ex neque necessitatibus provident
        consequuntur facere non repudiandae, porro, eum atque? Ex, soluta minima
        ea officia fugit pariatur.
      </p>
    </div>
  );
}

export default About