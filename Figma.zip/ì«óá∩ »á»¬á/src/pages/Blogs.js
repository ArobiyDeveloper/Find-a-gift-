import React from 'react'
import '../pages/Blogs.css'
import {
  BrowserRouter as Router,
  Routes,
  Route,
  NavLink,
} from "react-router-dom";

function Blogs() {
  return (
    <div className="blog">
      <div className="blog_text">
        <h1 className="b_h1">Our Best Blogs Ever</h1>
        <p className="b_p">
          “Try our blog to find the best tips and tricks to select your gift”
        </p>
      </div>
      <div className="b_img">
        <div className="img">1</div>
        <div className="advice">
          <div className="ad_text">
            <h4 className="ad_h4">Mr. John Doe</h4>
            <h1 className="ad_h1">The best way to wish your wife</h1>
            <div className="ad_link">
              <a href="#" className="ad_href">
                Read More
              </a>
            </div>
          </div>
        </div>
      </div>
      <div className="white_blog">
        <div className="whtb_one">
          <h1 className="whtb_h1">
            Database to find the gifts for your girlfriend
          </h1>
          <p className="whtb_p">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore...
          </p>
          <div className="whtb_link">
            <a href="#" className="whtb_href">
              Read More
            </a>
          </div>
        </div>
        <div className="whtb_two">
          <h1 className="whtb_h1">
            How Artificial Intelligence read your mind to find the best gift
          </h1>
          <p className="whtb_p">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore...
          </p>
          <div className="whtb_link">
            <a href="#" className="whtb_href">
              Read More
            </a>
          </div>
        </div>
      </div>
      <div className="end_container">
        <div className="end_links">
          <navbar>
            <NavLink to="/">Home</NavLink>
            <NavLink to="/about">About</NavLink>
            <div className="logo"></div>
            <NavLink to="/contact">Contact</NavLink>
            <NavLink to="/services">Services</NavLink>
            <NavLink to="/blogs">Blogs</NavLink>
          </navbar>
        </div>
        <hr />
        <div className="end_social">
          <div className="social_net">
            <a href="#" className="social_med"></a>
            <a href="#" className="social_med"></a>
            <a href="#" className="social_med"></a>
            <a href="#" className="social_med"></a>
            <a href="#" className="social_med"></a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Blogs