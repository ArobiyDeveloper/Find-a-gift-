import React from 'react'
import { Link } from 'react-router-dom';
import '../pages/Gifts.css'

function Gifts() {
  return (
    <div className="banner_item">
      <div className="banner_title">
        <h1 className="gift_h1">Gifts for all Occasions</h1>
        <p className="gift_p">
          “Try our web app to find the best gifts for all occasions”
        </p>
      </div>
      <div className="banner_box">
        <div className="box">
          <div className="box_img_1"></div>
          <h3>Birthday</h3>
          <div className="link">
            <Link>See More</Link>
          </div>
        </div>
        <div className="box">
          <div className="box_img_2"></div>
          <h3>Anniversary</h3>
          <div className="link">
            <Link>See More</Link>
          </div>
        </div>
        <div className="box">
          <div className="box_img_3"></div>
          <h3>Valentine's Day</h3>
          <div className="link">
            <Link>See More</Link>
          </div>
        </div>
        <div className="box">
          <div className="box_img_4"></div>
          <h3>Christmas</h3>
          <div className="link">
            <Link>See More</Link>
          </div>
        </div>
      </div>
      <div className="yellow_banner">
        <div className="yellow_text">
          <h1 className="yellow_h1">Ready to get started?</h1>
          <p className="yellow_p">Sign up or contact us</p>
        </div>
        <div className="yellow_links">
          <a href="#" className="y_link">
            Find gift now
          </a>
          <a href="#" className="y_link_1">
            How it works
          </a>
        </div>
      </div>
    </div>
  ); 
  
 
}

export default Gifts