import React from 'react'
import '../pages/Container.css'

function Container() {
  return (
    <div className="container">
      <div className="block_item">
        <div className="block_1">
          <div className="block_text">
            <h1 className="block_h1">
              Find a gift for your wife or girlfriend
            </h1>
            <p className="block_p">
              Struggling to find a gift for your wife or girlfriend? No problem!
            </p>
            <a href="#" className="block_href">
              Find gift now
            </a>
          </div>
        </div>
        <div className="block_1">
          <div className="block_img"></div>
        </div>
      </div>
      <div className="block_item_2">
        <div className="block_2">
          <div className="block_img_2"></div>
        </div>
        <div className="block_2">
          <div className="block_text_2">
            <h1 className="block_h1_2">How we work</h1>
            <p className="block_p_2">
              We’ve actually already asked hundreds of women what they want, and
              made a database with the results. All you have to do is take our
              short survey that only takes seconds, and our proprietary
              algorithm will match you with a few perfect gift options.
            </p>
            <a href="#" className="block_href_2">
              Learn More
            </a>
          </div>
        </div>
      </div>
     
    </div>
  );
}

export default Container