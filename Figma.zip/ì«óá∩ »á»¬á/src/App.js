import './App.css';
import "./pages/Home";
import "./pages/Contact";
import "./pages/About";
import Home from './pages/Home';
import About from './pages/About';
import Contact from "./pages/Contact";
import Services from "./pages/Services";
import Blogs  from "./pages/Blogs";
import Container from './pages/Container';
import Gifts from './pages/Gifts'

import{BrowserRouter as Router,Routes, Route, NavLink} from 'react-router-dom'


function App() {
  return (
    <div className="App">
      <Router>
        <nav>
          <NavLink to="/">Home</NavLink>
          <NavLink to="/about">About</NavLink>
          <NavLink to="/contact">Contact</NavLink>
          <NavLink to="/services">Services</NavLink>
          <NavLink to="/blogs">Blogs</NavLink>
          <NavLink to="/gift"> Gift Finder</NavLink>
        </nav>
        <Container />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/services" element={<Services />} />
          <Route path="/blogs" element={<Blogs />} />
        </Routes>
      <Gifts />
      <Blogs/>
      </Router>

    </div>
  );
}

export default App;
